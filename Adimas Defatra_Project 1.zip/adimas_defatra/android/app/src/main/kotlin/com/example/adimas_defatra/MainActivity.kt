package com.example.adimas_defatra

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
