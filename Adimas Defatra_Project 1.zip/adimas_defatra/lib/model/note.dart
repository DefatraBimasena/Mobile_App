import 'package:flutter/foundation.dart';

class Note {
  String id;
  String title;
  String description;
  String createdAt;

  Note(this.title, this.description, this.createdAt, {this.id = ''});

  // factory Note.fromJson(Map<String, dynamic> json) {
  //   return Note(
  //     json['title'] as String,
  //     json['description'] as String,
  //     json['createdAt'] as String,
  //     id: json['id'] as String,
  //   );
  // }

  // Map<String, dynamic> toJson() {
  //   return {
  //     'id': id,
  //     'title': title,
  //     'description': description,
  //     'createdAt': createdAt,
  //   };
  // }
}
